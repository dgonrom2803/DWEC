function comillas1() {
    var mensaje1 = "Comillas 1";
    
    alert(mensaje1);
  }
  function comillas2() {
    var mensaje2 = 'Comillas 2';
    
    alert(mensaje2);
  }