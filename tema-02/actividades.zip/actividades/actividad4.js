function numero() {
    var num = 5;
    const PI = 3.14159; 
    alert(num);
    alert(PI);
  }